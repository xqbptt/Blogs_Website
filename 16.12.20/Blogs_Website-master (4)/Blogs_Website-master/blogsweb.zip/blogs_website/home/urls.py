from . import views
from django.urls import path
from home.models import Bookmark

urlpatterns = [
    path('', views.index),
    path('discover', views.discover),
    path('input', views.input),
    path('search', views.search_index),
    path('search/dis', views.search_discover),    
    path('delete/<post_id>',views.delete_post,name='delete'),
]
